import bpy
from .version import *


def apply_modifier(mod_name):     
    if bpy.app.version >= (2,90,0):
        bpy.ops.object.modifier_apply(modifier=mod_name)
    else:
        bpy.ops.object.modifier_apply(apply_as="DATA", modifier=mod_name)